<footer id="colophon" class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h3>Contact Us</h3>
                <ul class="contact-info">
                    <li><i class="bi bi-envelope"></i> Email: <?php echo get_theme_mod('contact_email', 'comicrockemporium@gmail.com'); ?></li>
                    <li><i class="bi bi-phone"></i> Phone: <?php echo get_theme_mod('contact_phone', '123-456-7890'); ?></li>
                    <li><i class="bi bi-geo-alt"></i> Address: <?php echo get_theme_mod('contact_address', '123 bigd St, Orillia, Canada'); ?></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h3>Explore</h3>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer-menu',
                    'container' => false,
                    'menu_class' => 'footer-menu list-unstyled', // Added 'list-unstyled' for Bootstrap styling
                ));
                ?>
            </div>
            <div class="col-md-4"> <!-- Align content to end in medium and larger screens -->
                <h3>Follow Us</h3>
                <div class="footer-socials">
                    <a href="<?php echo get_theme_mod('instagram_link', '#'); ?>"><i class="bi bi-instagram"></i></a>
                    <a href="<?php echo get_theme_mod('facebook_link', '#'); ?>"><i class="bi bi-facebook"></i></a>
                    <a href="<?php echo get_theme_mod('twitter_link', '#'); ?>"><i class="bi bi-twitter"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="site-info bg-dark text-white py-3"> <!-- Added Bootstrap classes for styling -->
        <div class="container">
            <p class="m-0 text-center">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All Rights Reserved.</p>
        </div>
    </div>
</footer>