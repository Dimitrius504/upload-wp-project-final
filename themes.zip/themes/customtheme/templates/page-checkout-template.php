<?php
/*
 * Template Name: Checkout Page
 */
get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <div>
            <div>
                <section class="checkout-content">
                    <h1>Checkout</h1>
                    <?php
                    echo do_shortcode('[woocommerce_checkout]');
                    ?>
                </section>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
?>
