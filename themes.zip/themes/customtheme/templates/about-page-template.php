<?php
/*
Template Name: About Page
*/
get_header();
?>

<main id="primary" class="about-main">
    <div class="container">
        <article>
            <section class="header-section">
                <h1>Welcome to ComicRock Emporium</h1>
                <p>Discover Our Story</p>
            </section>

            <section id="our-story" class="about-section">
                <h2>Our Story</h2>
                <p>Welcome to ComicRock Emporium, where passion for nerdy and rock memorabilia meets a love for all
                    things collectible. Our journey began with a shared enthusiasm for comics, records, and everything
                    in between.</p>
                <p>Driven by the desire to create a haven for fellow enthusiasts, ComicRock Emporium was born. Since our
                    inception, we've been dedicated to providing a unique and diverse selection of merchandise that
                    celebrates the essence of nerd and rock culture.</p>
                <p>From rare comic editions to vintage vinyl records, we take pride in curating a collection that caters
                    to every fan's taste. Our commitment to quality, authenticity, and exceptional customer service sets
                    us apart.</p>
            </section>

            <section id="mission-values" class="about-section">
                <h2>Mission and Values</h2>
                <p>Our mission at ComicRock Emporium is simple: to provide a one-of-a-kind shopping experience that
                    celebrates the nostalgia and excitement of nerd and rock culture. We strive to create a welcoming
                    environment where fans can connect, explore, and indulge in their passions.</p>
                <p>At the heart of our values is a commitment to authenticity, integrity, and customer satisfaction. We
                    believe in fostering a community built on mutual respect and appreciation for the things that bring
                    us joy.</p>
            </section>

            <section class="contact-section">
                <h2>Contact Us</h2>
                <p>Got a question or feedback? We'd love to hear from you!</p>
                <p>Email: comicrockemporium@gmail.com</p>
                <p>Phone: 123-456-7890</p>
                <p>Address: 123 bigd St, Orillia, Canada</p>
            </section>
        </article>
    </div>
</main>

<?php
get_footer();
?>
