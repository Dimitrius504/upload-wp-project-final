<?php
/*
 * Template Name: Shop Page
 */
get_header();
?>

<main id="primary" class="shop-main">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="shop-content">
                    <?php
                    $shopFeaturedImg = wp_get_attachment_image_src(get_post_thumbnail_id(wc_get_page_id('shop')), 'full');

                    // Check if $shopFeaturedImg is an array before accessing its offset
                    if (is_array($shopFeaturedImg) && isset($shopFeaturedImg[0])) {
                        $background_style = 'style="background: url(\'' . $shopFeaturedImg[0] . '\');"';
                    } else {
                        // Fallback background style if no featured image found
                        $background_style = '';
                    }
                    ?>
                    <section class="shop-masthead" <?php echo $background_style; ?>>
                        <div>
                            <h1>Take A Look Around!</h1>
                        </div>
                    </section>


                    <section class="shop-body">
                        <div class="product-list">
                            <?php
                            // Display all WooCommerce products
                            $products = new WP_Query(
                                array(
                                    'post_type' => 'product',
                                    'posts_per_page' => -1,
                                )
                            );

                            if ($products->have_posts()):
                                while ($products->have_posts()):
                                    $products->the_post();
                                    ?>
                                    <div class="product-card">
                                        <?php if (has_post_thumbnail()): ?>
                                            <div class="product-image">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_post_thumbnail('medium', array('class' => 'product-thumbnail')); ?>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="product-info">
                                            <h2 class="product-title">
                                                <?php the_title(); ?>
                                            </h2>
                                            <div class="product-actions">
                                                <a href="<?php the_permalink(); ?>" class="button">See More</a>
                                                <?php woocommerce_template_loop_add_to_cart(); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                endwhile;
                                wp_reset_postdata();
                            else:
                                echo 'No products found';
                            endif;
                            ?>
                        </div>
                    </section>
                </section>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
?>