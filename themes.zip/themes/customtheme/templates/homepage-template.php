<?php
/**
 * Template Name: Homepage
 * Template Post Type: page
 */
get_header();
?>
<!-- Masthead-->
<section class="masthead" style="background-color: black;"> <!-- You can adjust background color as needed -->
    <div class="container">
        <img src="<?php echo get_template_directory_uri(); ?>/screenshot.png" alt="Masthead Image">
        <div class="masthead-subheading">Welcome To Comic Rock Emporium!</div>
        <div class="masthead-heading text-uppercase">Find Your Collector's Treasures</div>
        <a class="btn btn-primary btn-xl text-uppercase" href="#services">Explore Now</a>
    </div>
</section>

<!-- Reviews-->
<section class="page-section" id="services">
    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Customer Reviews</h2>
            <h3 class="section-subheading text-muted">Read the great things are customers say!</h3>
        </div>
        <div class="row text-center">
            <?php
            $args = array(
                'post_type' => 'review',
                'posts_per_page' => 3, // Number of reviews to display
                'orderby' => 'date',
                'order' => 'DESC',
            );
            $reviews_query = new WP_Query($args);

            if ($reviews_query->have_posts()):
                while ($reviews_query->have_posts()):
                    $reviews_query->the_post();
                    ?>
                    <div class="col-md-4">
                        <span class="fa-stack fa-4x">
                            <i class="fas fa-circle fa-stack-2x text-primary"></i>
                            <i class="fas fa-comment fa-stack-1x fa-inverse"></i>
                        </span>
                        <h4 class="my-3">
                            <?php the_title(); ?>
                        </h4>
                        <p class="text-muted">
                            <?php the_excerpt(); ?>
                        </p>
                    </div>
                    <?php
                endwhile;
            else:
                // If no reviews found
                echo '<p>No reviews found.</p>';
            endif;
            wp_reset_postdata();
            ?>
        </div>
    </div>
</section>



<!-- Featured Products -->
<section class="page-section bg-light" id="featured-products">
    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Featured Products</h2>
            <h3 class="section-subheading text-muted">Explore our latest additions.</h3>
        </div>
        <div class="row">
            <?php
            // Query to get 3 random products
            $featured_args = array(
                'post_type' => 'product',
                'posts_per_page' => 3, // Number of products to display
                'orderby' => 'rand', // Order by random
            );
            $featured_query = new WP_Query($featured_args);

            if ($featured_query->have_posts()):
                while ($featured_query->have_posts()):
                    $featured_query->the_post();
                    ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <?php if (has_post_thumbnail()): ?>
                                <a href="<?php the_permalink(); ?>" class="featured-product-image-link">
                                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" class="card-img-top" alt="<?php the_title(); ?>">
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php
                endwhile;
                wp_reset_postdata();
            else:
                // If no products found
                echo '<p>No products found.</p>';
            endif;
            ?>
        </div>
    </div>
    <div class="container text-center">
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>"
            class="btn btn-primary btn-xl text-uppercase">View More Products</a>
    </div>
</section>

<!-- Review Submission Form -->
<section id="review-form">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="text-center mb-5">
                    <h2 class="section-heading">Submit Your Review</h2>
                    <p class="text-muted">We'd love to hear your thoughts!</p>
                </div>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <input type="hidden" name="action" value="submit_review">
                    <div class="mb-3">
                        <label for="review_title" class="form-label">Review Title</label>
                        <input type="text" name="review_title" id="review_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="review_content" class="form-label">Your Review</label>
                        <textarea name="review_content" id="review_content" class="form-control" rows="5"
                            required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="review_author" class="form-label">Your Name</label>
                        <input type="text" name="review_author" id="review_author" class="form-control" required>
                    </div>
                    <div class="text-center" id="review-form-btn">
                        <button type="submit" class="btn btn-primary btn-lg text-uppercase">Submit Review</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>



<!-- Bootstrap core JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<?php
get_footer();
?>
</body>

</html>