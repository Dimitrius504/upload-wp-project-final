<?php
/*
 * Template Name: Cart Page
 */
get_header();
?>

<main id="primary" class="site-main">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <section class="cart-content">
                    <h1>Shopping Cart</h1>
                    <div class="cart-table">
                        <?php
                        echo do_shortcode('[woocommerce_cart]');
                        ?>
                    </div>
                    <div class="cart-actions">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="<?php echo esc_url('/shop'); ?>" class="button continue-shopping">Continue Shopping</a>
                            </div>
                            <div class="col-md-6 text-right">
                                <?php do_action('woocommerce_cart_actions'); ?>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
?>
