<?php
// Handle Review Submission
function handle_review_submission()
{
    if (isset($_POST['action']) && $_POST['action'] == 'submit_review') {
        $review_title = sanitize_text_field($_POST['review_title']);
        $review_content = wp_kses_post($_POST['review_content']);
        $review_author = sanitize_text_field($_POST['review_author']);

        // Create new post
        $post_args = array(
            'post_title' => $review_title,
            'post_content' => $review_content,
            'post_author' => get_current_user_id(), // Get the current user ID
            'post_status' => 'publish', // Publish the review immediately
            'post_type' => 'review',
        );
        $post_id = wp_insert_post($post_args);

        // Redirect the user to the homepage after submission
        wp_redirect(home_url('/home')); // Redirect to homepage
        exit;
    }
}
add_action('admin_post_submit_review', 'handle_review_submission');
add_action('admin_post_nopriv_submit_review', 'handle_review_submission'); // Allow non-logged in users to submit reviews

// Register shortcode
function custom_news_post_archive_shortcode()
{
    ob_start(); // Start output buffering

    ?>
    <section class="post-categories">
        <ul>
            <?php
            $categories = get_categories();
            foreach ($categories as $category) {
                echo '<li><a href="' . get_category_link($category->term_id) . '">' . $category->name . '</a></li>';
            }
            ?>
        </ul>
    </section>

    <section class="post-loop">
        <div class="posts">
            <div class="row">
                <?php
                $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => 4, // Displaying 4 posts to fit 2 by 2 grid
                    'paged' => $paged
                );
                $query = new WP_Query($args);
                if ($query->have_posts()):
                    while ($query->have_posts()):
                        $query->the_post();
                        ?>
                        <div class="col-md-6">
                            <article class="post-card">
                                <h2>
                                    <?php the_title(); ?>
                                </h2>
                                <div class="post-content">
                                    <?php the_excerpt(); ?>
                                    <a href="<?php the_permalink(); ?>" >Read More</a>
                                </div>
                                <!-- <div class="post-read-more">
                                    <a href="<?php the_permalink(); ?>" class="btn btn-primary">Read More</a>
                                </div> -->
                                <div class="post-tags">
                                    <?php
                                    $tags = get_the_tags();
                                    if ($tags) {
                                        foreach ($tags as $tag) {
                                            echo '<span class="tag">' . $tag->name . '</span>';
                                        }
                                    }
                                    ?>
                                </div>
                            </article>
                        </div>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                else:
                    echo 'No posts found';
                endif;
                ?>
            </div>
        </div>
        <?php
        // Pagination
        echo paginate_links(
            array(
                'total' => $query->max_num_pages
            )
        );
        ?>
    </section>
    <?php

    return ob_get_clean(); // Return the buffered output
}

add_shortcode('custom_news_post_archive', 'custom_news_post_archive_shortcode'); // Register shortcode

function enqueue_custom_scripts()
{
    // Enqueue my custom JavaScript file
    wp_enqueue_script('custom-script', get_template_directory_uri() . '/assets/js/script.js', array(), '1.0', false);
}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');



?>