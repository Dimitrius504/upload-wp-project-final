<?php
/**
 * Template Name: Custom News Post Archive
 */
get_header();
?>

<?php echo do_shortcode('[custom_news_post_archive]'); ?>

<?php get_footer(); ?>
