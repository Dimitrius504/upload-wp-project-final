// Get the header element
var header = document.getElementById("mainHeader");

// Get the initial offset position of the header
var sticky = header.offsetTop;

// Add the scroll event listener
window.onscroll = function() {scrollFunction()};

// Function to add or remove the 'shrink' class based on scroll position
function scrollFunction() {
    if (window.pageYOffset > sticky) {
        header.classList.add("shrink");
    } else {
        header.classList.remove("shrink");
    }
}

function test() {
    alert('stop')
}

test();
